#!/usr/bin/env python

import os
folder = "./imagessim_passed"
images = os.listdir(folder)
num = 0
for i in images:
	os.rename(
		os.path.join(folder, str(i)),
		os.path.join(folder, str("image_"+ str(num)))
		)
	num +=1